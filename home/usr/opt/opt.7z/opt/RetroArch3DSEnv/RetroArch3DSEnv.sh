#!/bin/bash
export PATH="/d/Users/jonat/bin:/d/Users/jonat/usr/bin:$PATH"
export DEVKITPRO="/c/devkitPro"
export DEVKITARM="$DEVKITPRO/devkitARM"
export CTRULIB="$DEVKITPRO/libctru"
export CTRBANNERTOOL="/d/Users/jonat/opt/RetroArchDev/CompatFiles/bannertool.exe"
bash
