Readme

- This is a list of modifications made to the master script. This collection of scripts works as of AHK version 1.1.24.03.

	1. The EditMyCommands and EditMyHotkeys functions now look up the default text editor using StandardLibrary.ahk in favor over the commented lines. This avoids having to rely on the edit verb's default value for Notepad, or working around that hacking the registry which requires admin privileges. However, if you can run things in administrator mode, then you can optionally run the ChangeEditVerb.ahk utility found in the Tools folder if that's to your liking.
